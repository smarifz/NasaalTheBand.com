<?php 
/**
* Author:	Omar Muhammad
* Email:	Knightofbaghdad@yahoo.com
* Plugin:	Component as Content
* Version:	1.5.2
* Date:		30/5/2009
**/

defined('_JEXEC') or die('Restricted access');
$mainframe->registerEvent('onPrepareContent', 'plgContentcomascon');
?>

<script type="text/javascript">
<!--
function applycss(id,file,file2,fheight,bgcolor)
	{
	var oIframe = document.getElementById(id);
	var oDoc = oIframe.contentWindow || oIframe.contentDocument;
	if (oDoc.document)
		{oDoc = oDoc.document;}
	addcss(oDoc,file);
	if (file2!="") 	addcss(oDoc,file2);
	if (bgcolor!="") oDoc.body.style.backgroundColor = bgcolor;
	oIframe.height = (fheight != "auto") ? fheight : (oDoc.body.offsetHeight !== undefined) ? oDoc.body.offsetHeight : oDoc.height;
	}
function addcss(item,file)
	{
	var link = item.createElement('link');
	link.setAttribute('rel', 'stylesheet');
	link.setAttribute('type', 'text/css');
	link.setAttribute('href', file);
	item.getElementsByTagName('head')[0].appendChild(link);
	}
-->
</script>
<?php

function plgContentcomascon(&$row, &$params, $page=0) {
	if (strpos($row->text, 'comascon') === false)
		{return true;}

	$regex = "#{comascon}(.*?){/comascon}#s";

	$row->text = preg_replace_callback($regex, 'botComponentCode_replacer', $row->text);
	return true;
}

function botComponentCode_replacer(&$matches) {
	global $database;
	$query = "SELECT params FROM #__plugins WHERE element = 'comascon' AND folder = 'content'";
	$database=&JFactory::getDBO();
	$database->setQuery($query);
	$plugin =& JPluginHelper::getPlugin('content', 'comascon');
 	$pluginParams = new JParameter($plugin->params);
	$height	= $pluginParams->set('height','500');
	$width	= $pluginParams->def('width','500');
	$scroll = $pluginParams->def('scroll','no');
	$parentopen = $pluginParams->def('parentopen', '0');
	$bgcolor="";
	$css="";
	if (strpos($matches[1],'|') == true)
		{
		$params = explode('|',$matches[1]);
		$matches[1] = $params[0];
		$parmsnumb = count($params);
		for ($i=1; $i<$parmsnumb; $i++)
			{
			$width = stristr($params[$i],"w=") ? str_replace('w=','',$params[$i]) : $width;
			$height = stristr($params[$i],"h=") ? str_replace('h=','',$params[$i]) : $height;
			$bgcolor = stristr($params[$i],"bg=") ? str_replace('bg=','',$params[$i]) : $bgcolor;
			$usercss = stristr($params[$i],"css=") ? str_replace('css=','',$params[$i]) : $css;
			}
		}
	$frameid = "comascon".(int)(microtime()*100000);
	$app =& JFactory::getApplication();
	$maincss = JURI::base()."templates/".$app->getTemplate()."/css/template.css";

	$url =	"\n<!-- Component as Content 1.5.2 starts here -->\n".
			"<div".(($height!="auto") ? "" : " onmouseout='applycss(\"$frameid\",\"$maincss\",\"$usercss\",\"$height\",\"$bgcolor\")'")."><iframe id='$frameid' src='index2.php?".$matches[1]."' width='$width' ".(($height!="auto") ? "height='$height' " : "")."frameborder='0' scrolling='$scroll'></iframe></div>\n";
	$url .= "<script type='text/javascript'>
			<!--
			window.setTimeout('applycss(\"$frameid\",\"$maincss\",\"$usercss\",\"$height\",\"$bgcolor\");', 3000);
			-->
			</script>";
	$url .= "\n<!-- Component as Content 1.5.2 ends here -->\n";
	return $url;
}
?>
