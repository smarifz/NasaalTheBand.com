General Info:
--------------------
Author:		Omar Muhammad
Email:		Knightofbaghdad@yahoo.com
Plugin:		Component as Content
Version:	1.5.2
Date:		30/5/2009


Change Log:
--------------------
* The Long-Awated Css Styling is now working!, The Plugin will automatically add the style of the site's template to the component.
* The admin can add an additional css file from anywhere in the web.
* This version is incompatable with previous versions, please read through the ReadMe file carefully before installing the plugin.
* Fixed an issue where a notice appeared if notices were enabled in (php.ini).


Installation:
--------------------
1-	Uninstall any previous versions of (Component as Content plugin)
2-	Install the new version normally from the Joomla! Administration Area
3-	Enable the plugin from the Plugin Manager


Usage:
--------------------
Component as Content is used through writing a code inside your articles.
this code consists of: starting tag, component path, paramiters(optional), ending tag.

starting tag:
	a tag to recognize the component you want to display.

	example:
	{comascon}

component path:
	the path of the component without the "index.php?"

	example:
	option=com_easybook&view=entry&layout=form&Itemid=45

parameters:
	to change or add specific options to the component, each paramiter is proceded by the "|" symbol
	you can choose to include or ignore any parameter
	if a parameter is ignored, the default parameter will be loaded, you can change the default parameters from the plugin window in the plugin manager.
	
	examples of allowed values:
	w=		550								(the width of the component in pixles)
	h=		600		or	auto				(the height of the component, can be either specific or auto)
	bg=		#ccc	or	red					(the background color of the component, either in hex or html-supported colors, change to suit your website)
	css=	http://fullpath/file.css		(add an additional css file to style the component)
	
	example:
	|w=500|h=auto|bg=green|css=http://mysite.com/templates/mytemp/css/mycss.css

end tag:
	a tag to recognize the end of the code
	
	example:
	{/comascon}

final code:
-----------------
examples:

{comascon}option=com_easybook&view=entry&layout=form&Itemid=45|w=550|h=auto{/comascon}

{comascon}option=com_easybook&view=entry&layout=form&Itemid=45|w=500|h=800|bg=#eeffaa|css=http://mysite.com/templates/mytemp/css/mycss.css{/comascon}

{comascon}option=com_easybook&view=entry&layout=form&Itemid=45|h=600|bg=blue|css=http://othersite.com/templates/sometemp/css/somecss.css{/comascon}
